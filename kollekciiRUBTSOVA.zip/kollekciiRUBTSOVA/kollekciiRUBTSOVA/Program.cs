﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace kollekciiRUBTSOVA
{
    class Program
    {
        //1 zadanie Stack - Consol
        /* static void Main(string[] args)
         {
             Stack<char> st = new Stack<char>();
             Console.WriteLine("Введите имя файла");
             string f = Console.ReadLine();
             if (!(File.Exists(f)))
             {
                 Console.WriteLine("данного файла не существует");
                 Console.ReadKey();
                 return;
             }
             else
             {
                 string text = File.ReadAllText(f);
                 Console.WriteLine("====Числа исходного файла===");
                 for (int i = 0; i < text.Length; i++)
                 {
                     string Str = "" + text[i];
                     Console.WriteLine(Str);
                     foreach (char ch in Str.ToCharArray())
                         st.Push(ch);
                 }
             }
             Console.WriteLine("\n\n===То, что мы записываем в новый файл===");
             foreach (char s in st)
                 using (StreamWriter file = new StreamWriter("f2.txt", true, Encoding.Unicode))
                 {
                     Console.Write(s);
                     file.Write(s);
                 }
             Console.ReadKey();
         }*/

        //4 zadanie Queue - Consol
        static void Main(string[] args)
        {

            if (File.Exists("numbers.txt"))
            {
                Queue<int> positive = new Queue<int>();
                Queue<int> negaitive = new Queue<int>();
                StreamReader text = File.OpenText("numbers.txt");// 5 -3 11 2 -8 -3 9                                         
                while (!text.EndOfStream)
                {
                    string st = text.ReadLine();
                    Console.WriteLine("====Числа исходного файла===");
                    Console.WriteLine(st);
                    string[] numbers = st.Split(' ');
                    for (int i = 0; i < numbers.Length; i++)
                    {
                        int number = Convert.ToInt32(numbers[i]);
                        if (number > 0) positive.Enqueue(number);
                        if (number < 0) negaitive.Enqueue(number);
                    }
                }
                text.Close();
                Console.WriteLine("Положительные");
                foreach (int number in positive)
                {
                    Console.WriteLine($"{number}");
                }
                Console.WriteLine();
                Console.WriteLine("Отрицательные");
                foreach (int number in negaitive)
                {
                    Console.WriteLine($"{number}");
                }
            }
            else Console.WriteLine("данного файла не существует");
            Console.ReadKey();
        }

    }
}
