﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Rubtsova_koll_FORMA
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (File.Exists("text.txt"))
            {
                Queue<string> propis = new Queue<string>();
                Queue<string> stroch = new Queue<string>();               
                string[] words = File.ReadAllText("text.txt").Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);               
                foreach (string word in words)
                {
                    if (char.IsUpper(word[0]))
                    {
                        propis.Enqueue(word);
                    }
                    else
                    {
                        stroch.Enqueue(word);
                    }
                }
                listBox1.Items.Add("Прописные:");
                while (propis.Count > 0)
                {
                    listBox1.Items.Add($"\n{propis.Dequeue()}");
                }
                listBox1.Items.Add("Строчные:");
                while (stroch.Count > 0)
                {
                    listBox1.Items.Add($"\n {stroch.Dequeue()}");
                }
            }
            else MessageBox.Show("данного файла не существует");
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
    }      
    

